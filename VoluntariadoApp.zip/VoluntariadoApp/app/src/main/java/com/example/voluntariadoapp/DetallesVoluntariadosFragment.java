package com.example.voluntariadoapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class DetallesVoluntariadosFragment extends Fragment {

    // Claves para los argumentos
    private static final String ARG_NOMBRE = "nombre";
    private static final String ARG_DESCRIPCION = "descripcion";
    private static final String ARG_UBICACION = "ubicacion";
    private static final String ARG_FECHA_INICIO = "fecha_inicio";
    private static final String ARG_FECHA_FIN = "fecha_fin";
    private static final String ARG_ORGANIZACION = "organizacion";

    // Método estático para crear una instancia del fragmento con los argumentos
    public static DetallesVoluntariadosFragment newInstance(String nombre, String descripcion, String ubicacion, String fechaInicio, String fechaFin, String organizacion) {
        DetallesVoluntariadosFragment fragment = new DetallesVoluntariadosFragment();
        Bundle args = new Bundle();
        args.putString(ARG_NOMBRE, nombre);
        args.putString(ARG_DESCRIPCION, descripcion);
        args.putString(ARG_UBICACION, ubicacion);
        args.putString(ARG_FECHA_INICIO, fechaInicio);
        args.putString(ARG_FECHA_FIN, fechaFin);
        args.putString(ARG_ORGANIZACION, organizacion);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_detalles_voluntariados, container, false);

        // Obtener los argumentos
        Bundle args = getArguments();
        if (args != null) {
            String nombre = args.getString(ARG_NOMBRE);
            String descripcion = args.getString(ARG_DESCRIPCION);
            String ubicacion = args.getString(ARG_UBICACION);
            String fechaInicio = args.getString(ARG_FECHA_INICIO);
            String fechaFin = args.getString(ARG_FECHA_FIN);
            String organizacion = args.getString(ARG_ORGANIZACION);

            // Configurar los TextView
            ((TextView) view.findViewById(R.id.textViewNombreValue)).setText(nombre);
            ((TextView) view.findViewById(R.id.textViewDescripcionValue)).setText(descripcion);
            ((TextView) view.findViewById(R.id.textViewUbicacionValue)).setText(ubicacion);
            ((TextView) view.findViewById(R.id.textViewFechaInicioValue)).setText(String.valueOf(fechaInicio));
            ((TextView) view.findViewById(R.id.textViewFechaFinValue)).setText(String.valueOf(fechaFin));
            ((TextView) view.findViewById(R.id.textViewOrganizacionValue)).setText(organizacion);
        }

        return view;
    }
}
