package com.example.voluntariadoapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class ListaVoluntariadosFragment extends Fragment {

    private RecyclerView recyclerView;
    private VoluntariadoAdapter adapter;
    private List<Voluntariado> voluntariadosList = new ArrayList<>();
    private Button btnAgregarVoluntariado;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_lista_voluntariados, container, false);

        recyclerView = view.findViewById(R.id.recyclerView);
        btnAgregarVoluntariado = view.findViewById(R.id.btnAgregarVoluntariado);

        // Configurar RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new VoluntariadoAdapter(voluntariadosList);
        recyclerView.setAdapter(adapter);

        // Agregar nuevo voluntariado
        btnAgregarVoluntariado.setOnClickListener(v -> {
            AgregarVoluntariadoFragment agregarFragment = new AgregarVoluntariadoFragment();
            agregarFragment.show(getChildFragmentManager(), "AgregarVoluntariado");
        });

        // Función para apuntarse a un voluntariado
        adapter.setOnItemClickListener(voluntariado -> {
            // Obtener el userId del usuario autenticado
            String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
            DatabaseReference db = FirebaseDatabase.getInstance().getReference("voluntariados")
                    .child(voluntariado.getId()).child("inscritos");

            // Marcar que el usuario está inscrito
            db.child(userId).setValue(true);

            // Guardar en la lista de voluntariados del usuario
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("usuarios")
                    .child(userId).child("voluntariadosInscritos");
            userRef.child(voluntariado.getId()).setValue(true);

            Toast.makeText(getContext(), "Te has inscrito al voluntariado", Toast.LENGTH_SHORT).show();
        });

        return view;
    }
}
