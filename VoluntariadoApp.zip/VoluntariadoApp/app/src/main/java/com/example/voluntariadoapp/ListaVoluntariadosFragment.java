package com.example.voluntariadoapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ListaVoluntariadosFragment extends Fragment {

    private RecyclerView recyclerView;
    private VoluntariadoAdapter adapter;
    private List<Voluntariado> voluntariadosList = new ArrayList<>();
    private Button btnAgregarVoluntariado;
    private DatabaseReference voluntariadosRef;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_lista_voluntariados, container, false);

        recyclerView = view.findViewById(R.id.recyclerView);
        btnAgregarVoluntariado = view.findViewById(R.id.btnAgregarVoluntariado);

        // Configurar RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new VoluntariadoAdapter(voluntariadosList);
        recyclerView.setAdapter(adapter);

        // Referencia a Firebase
        voluntariadosRef = FirebaseDatabase.getInstance().getReference("voluntariados");

        // Cargar datos desde Firebase
        cargarVoluntariados();

        // Agregar nuevo voluntariado
        btnAgregarVoluntariado.setOnClickListener(v -> {
            AgregarVoluntariadoFragment agregarFragment = new AgregarVoluntariadoFragment();
            agregarFragment.show(getChildFragmentManager(), "AgregarVoluntariado");
        });

        // Función para apuntarse a un voluntariado
        adapter.setOnItemClickListener(voluntariado -> {
            String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
            DatabaseReference inscritosRef = voluntariadosRef.child(voluntariado.getId()).child("inscritos");

            // Marcar que el usuario está inscrito
            inscritosRef.child(userId).setValue(true);

            // Guardar en la lista de voluntariados del usuario
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("usuarios")
                    .child(userId).child("voluntariadosInscritos");
            userRef.child(voluntariado.getId()).setValue(true);

            Toast.makeText(getContext(), "Te has inscrito al voluntariado", Toast.LENGTH_SHORT).show();
        });

        return view;
    }

    private void cargarVoluntariados() {
        voluntariadosRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                voluntariadosList.clear();
                for (DataSnapshot voluntariadoSnapshot : snapshot.getChildren()) {
                    Voluntariado voluntariado = voluntariadoSnapshot.getValue(Voluntariado.class);
                    if (voluntariado != null) {
                        voluntariado.setId(voluntariadoSnapshot.getKey());

                        // Asegúrate de que las fechas están en formato String
                        String fechaInicio = voluntariado.getFechaInicio();
                        String fechaFin = voluntariado.getFechaFin();

                        // Puedes elegir mostrar las fechas como están o transformarlas en el formato que prefieras
                        // En este caso, las fechas son Strings y las mostramos tal cual

                        voluntariadosList.add(voluntariado);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getContext(), "Error al cargar los voluntariados: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
