package com.example.voluntariadoapp;

import android.app.Application;
import android.util.Log;

import com.google.firebase.FirebaseApp;

public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

        // Inicializar Firebase
        try {
            FirebaseApp.initializeApp(this);
            Log.d("FirebaseInit", "FirebaseApp initialized successfully in Application class");
        } catch (Exception e) {
            Log.e("FirebaseInit", "Error initializing Firebase in Application class", e);
        }
    }
}
