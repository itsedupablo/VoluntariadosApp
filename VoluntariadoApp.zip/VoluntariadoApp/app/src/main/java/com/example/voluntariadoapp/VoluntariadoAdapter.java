package com.example.voluntariadoapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class VoluntariadoAdapter extends RecyclerView.Adapter<VoluntariadoAdapter.VoluntariadoViewHolder> {

    private List<Voluntariado> listaVoluntariados;
    private OnItemClickListener listener;

    // Constructor del adaptador
    public VoluntariadoAdapter(List<Voluntariado> listaVoluntariados) {
        this.listaVoluntariados = listaVoluntariados;
    }

    // Interfaz para manejar clics en los elementos
    public interface OnItemClickListener {
        void onItemClick(Voluntariado voluntariado);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public VoluntariadoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_voluntariado, parent, false);
        return new VoluntariadoViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull VoluntariadoViewHolder holder, int position) {
        Voluntariado voluntariado = listaVoluntariados.get(position);
        holder.bind(voluntariado);
    }

    @Override
    public int getItemCount() {
        return listaVoluntariados != null ? listaVoluntariados.size() : 0;
    }

    // Clase interna para representar un ViewHolder
    class VoluntariadoViewHolder extends RecyclerView.ViewHolder {
        private final TextView textViewNombre;
        private final TextView textViewUbicacion;
        private final TextView textViewFechaInicio;
        private final TextView textViewFechaFin;
        private final TextView textViewOrganizacion;

        private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());

        public VoluntariadoViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewNombre = itemView.findViewById(R.id.textViewNombre);
            textViewUbicacion = itemView.findViewById(R.id.textViewUbicacion);
            textViewFechaInicio = itemView.findViewById(R.id.textViewFechaInicio);
            textViewFechaFin = itemView.findViewById(R.id.textViewFechaFin);
            textViewOrganizacion = itemView.findViewById(R.id.textViewOrganizacion);

            itemView.setOnClickListener(v -> {
                if (listener != null && getAdapterPosition() != RecyclerView.NO_POSITION) {
                    listener.onItemClick(listaVoluntariados.get(getAdapterPosition()));
                }
            });
        }

        public void bind(Voluntariado voluntariado) {
            textViewNombre.setText(voluntariado.getNombre());
            textViewUbicacion.setText(voluntariado.getUbicacion());
            textViewFechaInicio.setText(dateFormat.format(voluntariado.getFechaInicio()));
            textViewFechaFin.setText(dateFormat.format(voluntariado.getFechaFin()));
            textViewOrganizacion.setText(voluntariado.getOrganizacion());
        }
    }
}
