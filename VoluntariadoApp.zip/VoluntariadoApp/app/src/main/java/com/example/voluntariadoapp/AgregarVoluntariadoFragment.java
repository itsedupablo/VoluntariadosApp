package com.example.voluntariadoapp;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.DialogFragment;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class AgregarVoluntariadoFragment extends DialogFragment {

    private EditText editTextNombre, editTextDescripcion, editTextUbicacion, editTextFechaInicio, editTextFechaFin, editTextOrganizacion;
    private Button buttonAgregar, buttonCancelar;
    private static final String TAG = "AgregarVoluntariado";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_agregar_voluntariado, container, false);

        // Inicializar los campos
        editTextNombre = view.findViewById(R.id.editTextNombre);
        editTextDescripcion = view.findViewById(R.id.editTextDescripcion);
        editTextUbicacion = view.findViewById(R.id.editTextUbicacion);
        editTextFechaInicio = view.findViewById(R.id.editTextFechaInicio);
        editTextFechaFin = view.findViewById(R.id.editTextFechaFin);
        editTextOrganizacion = view.findViewById(R.id.editTextOrganizacion);
        buttonAgregar = view.findViewById(R.id.btnAgregar);
        buttonCancelar = view.findViewById(R.id.btnCancelar);

        // Configurar el botón de agregar
        buttonAgregar.setOnClickListener(v -> {
            Log.d(TAG, "Botón 'Agregar' presionado");

            // Obtener valores de los campos
            String nombre = editTextNombre.getText().toString().trim();
            String descripcion = editTextDescripcion.getText().toString().trim();
            String ubicacion = editTextUbicacion.getText().toString().trim();
            String fechaInicio = editTextFechaInicio.getText().toString().trim();
            String fechaFin = editTextFechaFin.getText().toString().trim();
            String organizacion = editTextOrganizacion.getText().toString().trim();

            // Validar que los campos no estén vacíos
            if (nombre.isEmpty() || descripcion.isEmpty() || ubicacion.isEmpty() || fechaInicio.isEmpty() || fechaFin.isEmpty() || organizacion.isEmpty()) {
                Toast.makeText(getContext(), "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
                return;
            }

            // Crear un mapa de datos para Firebase
            Map<String, Object> voluntariadoData = new HashMap<>();
            voluntariadoData.put("nombre", nombre);
            voluntariadoData.put("descripcion", descripcion);
            voluntariadoData.put("ubicacion", ubicacion);
            voluntariadoData.put("fechaInicio", fechaInicio);
            voluntariadoData.put("fechaFin", fechaFin);
            voluntariadoData.put("organizacion", organizacion);

            // Obtener referencia a Firebase y guardar
            DatabaseReference databaseReference = FirebaseDatabase.getInstance()
                    .getReference("voluntariados");

            String voluntariadoId = databaseReference.push().getKey(); // Generar un ID único

            if (voluntariadoId != null) {
                databaseReference.child(voluntariadoId).setValue(voluntariadoData)
                        .addOnSuccessListener(aVoid -> {
                            Log.d(TAG, "Voluntariado agregado exitosamente");
                            Toast.makeText(getContext(), "Voluntariado agregado correctamente", Toast.LENGTH_SHORT).show();
                            dismiss(); // Cerrar el diálogo
                        })
                        .addOnFailureListener(e -> {
                            Log.e(TAG, "Error al agregar voluntariado", e);
                            Toast.makeText(getContext(), "Error al guardar el voluntariado", Toast.LENGTH_SHORT).show();
                        });
            } else {
                Log.e(TAG, "Error al generar ID para el voluntariado");
                Toast.makeText(getContext(), "Error al generar ID para el voluntariado", Toast.LENGTH_SHORT).show();
            }
        });

        // Configurar el botón de cancelar
        buttonCancelar.setOnClickListener(v -> {
            Log.d(TAG, "Botón 'Cancelar' presionado");
            dismiss();
        });

        return view;
    }


// Función para validar que todos los campos estén completos
    private boolean validarCampos() {
        return !editTextNombre.getText().toString().isEmpty() &&
                !editTextDescripcion.getText().toString().isEmpty() &&
                !editTextUbicacion.getText().toString().isEmpty() &&
                !editTextFechaInicio.getText().toString().isEmpty() &&
                !editTextFechaFin.getText().toString().isEmpty() &&
                !editTextOrganizacion.getText().toString().isEmpty();
    }
}
