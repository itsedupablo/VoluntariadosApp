package com.example.voluntariadoapp;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.DialogFragment;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AgregarVoluntariadoFragment extends DialogFragment {

    private EditText editTextNombre, editTextDescripcion, editTextUbicacion, editTextFechaInicio, editTextFechaFin, editTextOrganizacion;
    private Button buttonAgregar, buttonCancelar;

    private static final String TAG = "AgregarVoluntariadoFragment"; // Para logs

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_agregar_voluntariado, container, false);

        // Inicializar los campos del formulario
        editTextNombre = view.findViewById(R.id.editTextNombre);
        editTextDescripcion = view.findViewById(R.id.editTextDescripcion);
        editTextUbicacion = view.findViewById(R.id.editTextUbicacion);
        editTextFechaInicio = view.findViewById(R.id.editTextFechaInicio);
        editTextFechaFin = view.findViewById(R.id.editTextFechaFin);
        editTextOrganizacion = view.findViewById(R.id.editTextOrganizacion);
        buttonAgregar = view.findViewById(R.id.btnAgregar);
        buttonCancelar = view.findViewById(R.id.btnCancelar);

        // Configurar el botón de agregar
        buttonAgregar.setOnClickListener(v -> {
            Log.d(TAG, "Botón 'Agregar' presionado");

            // Verificar que todos los campos están llenos
            if (validarCampos()) {
                // Crear un nuevo voluntariado con los datos del formulario
                String nombre = editTextNombre.getText().toString();
                String descripcion = editTextDescripcion.getText().toString();
                String ubicacion = editTextUbicacion.getText().toString();
                String fechaInicio = editTextFechaInicio.getText().toString();
                String fechaFin = editTextFechaFin.getText().toString();
                String organizacion = editTextOrganizacion.getText().toString();

                // Crear un objeto Voluntariado
                Voluntariado nuevoVoluntariado = new Voluntariado(
                        nombre,
                        descripcion,
                        ubicacion,
                        fechaInicio,
                        fechaFin,
                        organizacion
                );

                // Agregar a Firebase
                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("voluntariados");
                databaseReference.push().setValue(nuevoVoluntariado)
                        .addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                // Mostrar un mensaje de éxito
                                Toast.makeText(getContext(), "Voluntariado agregado exitosamente", Toast.LENGTH_SHORT).show();
                                dismiss(); // Cerrar el fragmento
                            } else {
                                // Mostrar un mensaje de error
                                Log.e(TAG, "Error al agregar el voluntariado", task.getException());
                                Toast.makeText(getContext(), "Error al agregar el voluntariado", Toast.LENGTH_SHORT).show();
                            }
                        });
            } else {
                // Si faltan campos, mostrar un mensaje de advertencia
                Toast.makeText(getContext(), "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
            }
        });

        // Configurar el botón de cancelar
        buttonCancelar.setOnClickListener(v -> dismiss()); // Cerrar el fragmento si se cancela

        return view;
    }

    // Función para validar que todos los campos estén completos
    private boolean validarCampos() {
        return !editTextNombre.getText().toString().isEmpty() &&
                !editTextDescripcion.getText().toString().isEmpty() &&
                !editTextUbicacion.getText().toString().isEmpty() &&
                !editTextFechaInicio.getText().toString().isEmpty() &&
                !editTextFechaFin.getText().toString().isEmpty() &&
                !editTextOrganizacion.getText().toString().isEmpty();
    }
}
