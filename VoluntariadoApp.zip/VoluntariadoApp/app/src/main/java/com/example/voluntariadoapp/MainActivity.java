package com.example.voluntariadoapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Mis Voluntariados");

        // Cargar el fragmento de la lista al inicio
        if (savedInstanceState == null) {
            cargarFragmento(new ListaVoluntariadosFragment());
        }
    }

    private void cargarFragmento(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(android.R.id.content, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    public void onVoluntariadoSelected(Voluntariado voluntariado) {
        // Navegar al fragmento de detalles
        DetallesVoluntariadosFragment detallesFragment = DetallesVoluntariadosFragment.newInstance(
                voluntariado.getNombre(),
                voluntariado.getDescripcion(),
                voluntariado.getUbicacion(),
                voluntariado.getFechaInicio(),
                voluntariado.getFechaFin(),
                voluntariado.getOrganizacion()
        );
        cargarFragmento(detallesFragment);
    }
}
