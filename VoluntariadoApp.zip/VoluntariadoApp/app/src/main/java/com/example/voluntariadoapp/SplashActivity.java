package com.example.voluntariadoapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.example.voluntariadoapp.AccessActivity;
import com.example.voluntariadoapp.R;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);


        // Espera unos segundos antes de redirigir a AccessActivity
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            Intent intent = new Intent(SplashActivity.this, AccessActivity.class);
            startActivity(intent);
            finish(); // Cierra SplashActivity para evitar regresar a ella
        }, 3000); // 3000 ms = 3 segundos
    }
}
