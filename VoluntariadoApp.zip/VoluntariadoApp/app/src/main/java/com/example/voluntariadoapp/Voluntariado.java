package com.example.voluntariadoapp;

import java.util.List;
import java.util.ArrayList;

public class Voluntariado {
    private String id;
    private String nombre;
    private String descripcion;
    private String ubicacion;
    private String fechaInicio;
    private String fechaFin;
    private String organizacion;

    // Constructores
    public Voluntariado() {}
    public Voluntariado(String id, String nombre, String descripcion, String ubicacion,
                        String fechaInicio, String fechaFin, String organizacion) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.ubicacion = ubicacion;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.organizacion = organizacion;

    }

    // Getters y setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }


    public String getFechaFin() {
        return fechaFin;
    }

    public String getOrganizacion() {
        return organizacion;
    }


}
